import { PackagePlus } from "lucide-react"
import { AlertsHeader } from "@/components/alerts-header"
import { SummaryCards } from "@/components/summary-cards"
import { AlertCard } from "@/components/alert-card"
import { BottomNav } from "@/components/bottom-nav"
import { DesktopSidebar } from "@/components/desktop-sidebar"
import { stockAlerts } from "@/lib/alerts-data"

export default function AlertsPage() {
  return (
    <div className="min-h-screen bg-background">
      <DesktopSidebar active="alertas" />

      <main className="flex min-h-screen flex-col md:ml-[260px]">
        <div className="mx-auto flex w-full max-w-md flex-1 flex-col md:max-w-[900px]">
          <AlertsHeader />

          <div className="flex-1 overflow-y-auto pb-4 md:px-3">
            <SummaryCards criticalCount={5} warningCount={3} />

            <h2 className="px-5 pb-3 pt-6 text-xs font-bold uppercase tracking-wider text-muted-foreground md:px-5">
              Lista de alertas
            </h2>

            <div className="grid grid-cols-1 gap-3 px-5 md:grid-cols-2 md:gap-4">
              {stockAlerts.map((alert, index) => (
                <AlertCard key={alert.id} alert={alert} index={index} />
              ))}
            </div>
          </div>

          <div className="sticky bottom-0 z-10 border-t border-border bg-card/95 px-5 py-3 backdrop-blur md:static md:border-0 md:bg-transparent md:px-5 md:pb-8">
            <button
              type="button"
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-4 py-3.5 text-sm font-bold uppercase tracking-wide text-primary-foreground shadow-sm transition-all hover:bg-primary/90 active:scale-[0.99] md:w-auto md:px-6"
            >
              <PackagePlus className="size-5" />
              Registrar entrada
            </button>
          </div>
        </div>

        <BottomNav active="alertas" />
      </main>
    </div>
  )
}
